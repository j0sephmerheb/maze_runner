import pygame
import turtle

# Initialize the Pygame
pygame.init()

# for creating the screen
screen = pygame.display.set_mode((800, 800))

# Title and Icon
pygame.display.set_caption("Maze Gamers")
icon = pygame.image.load('person.png')
pygame.display.set_icon(icon)



# Player
playerImg = pygame.image.load('mammal.png')
playerX = 70
playerY = 100
playerX_change = 0
playerY_change = 0

wallImg = pygame.image.load('security.png')
wallX = 60
wallY = 30

def player(x, y):
    screen.blit(playerImg, (x, y))

def wall(x, y):
    screen.blit(wallImg, (x, y))




# Game Loop
running = True
while running:
    # background color
     screen.fill((153, 127, 143))

     for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerX_change = -2
            if event.key == pygame.K_RIGHT:
                playerX_change = +2
            if event.key == pygame.K_UP:
                playerY_change = -2
            if event.key == pygame.K_DOWN:
                playerY_change == +2
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
              if event.key == pygame.K_UP or event.key == pygame.K_DOWN:

                playerX_change = 0
                playerY_change = 0


        playerX += playerX_change
        playerY -= playerY_change
        player(playerX, playerY)
        wall(wallX, wallY)
        pygame.display.update()
